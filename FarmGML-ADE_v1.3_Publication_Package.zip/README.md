# FarmGML ADE v1.3 - Publication Package
Generated: 2025-10-26

This package contains the Model-Driven (MDA) source and the distribution artifacts
for FarmGML ADE v1.3, ready for publishing on GitHub Pages and submission to OGC.

Structure highlights:
- model/: UML/XMI source (source-of-truth)
- schemas/: distribution XSDs, codelists, examples
- docs/: specification PDF/HTML and schema reference
- tools/: ShapeChange config and scripts
- .ogc/: submission manifest and contact info
