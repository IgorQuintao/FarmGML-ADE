# Namespace policy
Base URI: http://www.exemplo.gov.br/schemas/ade/farmgml/1.3
