#!/bin/bash
# validate-xsd.sh - validates example GML against umbrella XSD
set -e
xmllint --noout --schema schemas/1.3/FarmGML.xsd schemas/1.3/examples/example_ruralproperty.gml
echo "Validation completed."
