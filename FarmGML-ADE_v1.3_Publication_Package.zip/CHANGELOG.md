# Changelog

- v1.3 (2025-10-25): Refactored MDA-ready package
